package com.example.listview;

import androidx.fragment.app.FragmentActivity;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {

   // MyHorizontalListAdapter adapter;
   // VerticalGridView verticalGridView;

    VerticalGridView rows;
    RecyclerView.Adapter adapter;
    ArrayList<Integer> row_position=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rows=findViewById(R.id.parent);

        adapter=new ParentRecyclerAdapter(this, row_position);
        rows.setAdapter(adapter);
        int[] position={0, 1, 2, 3};
        for(int i=0; i<position.length; i++)
        {
            row_position.add(position[i]);
        }
   //     adapter.notifyDataSetChanged();

  /*      ArrayList<String> listTitles = new ArrayList<String>();
        listTitles.add("Position 0");
        listTitles.add("Position 1");
        listTitles.add("Position 2");
        listTitles.add("Position 3");
        listTitles.add("Position 4");
        listTitles.add("Position 5");
        listTitles.add("Position 6");
        listTitles.add("Position 7");
        listTitles.add("Position 8");
        listTitles.add("Position 9");

        RecyclerView horizontal_list = findViewById(R.id.horizontal);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        horizontal_list.setLayoutManager(linearLayoutManager);
        adapter = new MyHorizontalListAdapter(this, listTitles);
        horizontal_list.setAdapter(adapter);*/
    }
}

/*
class MyHorizontalListAdapter extends RecyclerView.Adapter<MyHorizontalListAdapter.SimpleViewHolder> {

    private Context context;
    private List<String> texts;

    //data is passed into constructor
    public MyHorizontalListAdapter(Context context, List<String> texts) {
        this.context = context;
        this.texts=texts;
    }

    //stores and recycles views as they are scrolled off screen
    public static class SimpleViewHolder extends RecyclerView.ViewHolder {
        TextView listText;

        public SimpleViewHolder(View view) {
            super(view);
            listText = view.findViewById(R.id.eachLayout);
        }
    }

    //inflates the row layout from xml when needed
    @Override
    public SimpleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(this.context).inflate(R.layout.child_rowlayout, parent, false);
        return new SimpleViewHolder(view);
    }

    //binds data to textview in each row
    @Override
    public void onBindViewHolder(SimpleViewHolder holder, final int position) {
        String names=texts.get(position);
        holder.listText.setText(names);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return this.texts.size();
    }
}

*/