package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ParentRecyclerAdapter extends RecyclerView.Adapter<ParentRecyclerAdapter.MyViewHolder> {

    Context context;
    ArrayList<Integer> parentArrayList;
   // ArrayList<String> childArrayList = new ArrayList<>();

    ParentRecyclerAdapter(Context context, ArrayList<Integer> parentArrayList) {
        this.context = context;
        this.parentArrayList = parentArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.parent_rowlayout, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int position) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        myViewHolder.child.setLayoutManager(layoutManager);
        ArrayList<String> childArrayList = new ArrayList<>();
        String[] items = {"Item 0", "Item 1", "Item 2", "Item 3", "Item 4", "Item 5",
                "Item 6", "Item 7", "Item 8", "Item 9", "Item 10", "Item 11", "Item 12", "Item 13",
                "Item 14", "Item 15", "Item 16", "Item 17", "Item 18", "Item 19"};
      /*  for(int i=0; i<=10; i++)
        {
            while(i<6)
            {
                childArrayList.add(days[i]);
                i++;
            }
        }*/

        //  int item=parentArrayList.get(0);
        //  Toast.makeText(context, item+ "is the item at position 0", Toast.LENGTH_SHORT).show();
      /*   if (parentArrayList.get(position).equals(0)) {
            for (int i = 0; i < 6; i++) {
                childArrayList.add(items[i]);
            }
        }
        else if(parentArrayList.get(position).equals(1)) {
            for (int i = 6; i < 12; i++) {
                childArrayList.add(items[i]);
            }
        }
        else if(parentArrayList.get(position).equals(2)){
            for (int i = 12; i<18; i++) {
                childArrayList.add(items[i]);
            }
        }
        else
        {
            for(int i=18; i<=items.length-1; i++)
                childArrayList.add(items[i]);
        }*/


        int total_items = items.length;
        int count, start;

        //initialization
            if (parentArrayList.get(position).equals(0)) {
                if(total_items>6) {
                    count = 6;
                    start = 0;
                }
                else
                {
                    start=0;
                    count=total_items;
                }
            } else if (parentArrayList.get(position).equals(1)) {
                if(total_items>12) {
                    count = 12;
                    start = 6;
                }
                else
                {
                    start=6;
                    count=total_items;
                }
            } else if (parentArrayList.get(position).equals(2)) {
                if(total_items>18) {
                    count = 18;
                    start = 12;
                }
                else
                {
                    start=12;
                    count=total_items;
                }
            } else {
                start = 18;
                count = total_items;
            }

            //iteration
        for(int i=0; i<4; i++)
        {
            if(parentArrayList.get(position).equals(i))
            {
                for(i=start; i<count; i++)
                {
                    childArrayList.add(items[i]);
                }
            }
        }

   /*  int total_number_of_items=items.length-1;
     int count = 6;

     while(total_number_of_items%2==0) {
         if (parentArrayList.get(position).equals(0)) {
             for (int i = 0; i < 6; i++) {
                 childArrayList.add(items[i]);
             }
         }
     }*/

            ChildTextViewsAdapter childRecyclerAdapter = new ChildTextViewsAdapter(childArrayList);
            myViewHolder.child.setAdapter(childRecyclerAdapter);
        }

        @Override
        public int getItemCount () {
            return parentArrayList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            RecyclerView child;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                child = itemView.findViewById(R.id.child);
            }
        }
    }
