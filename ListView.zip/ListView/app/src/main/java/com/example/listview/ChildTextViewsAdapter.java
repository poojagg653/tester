package com.example.listview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ChildTextViewsAdapter extends RecyclerView.Adapter<ChildTextViewsAdapter.MyViewHolder> {

    ArrayList<String> arrayList;
    ChildTextViewsAdapter(ArrayList<String> arrayList)
    {
        this.arrayList=arrayList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.child_rowlayout, viewGroup, false);
        return new ChildTextViewsAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.items.setText(arrayList.get(i));
    }

    @Override
    public int getItemCount() {

        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView items;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            items=itemView.findViewById(R.id.eachLayout);
        }
    }
}
